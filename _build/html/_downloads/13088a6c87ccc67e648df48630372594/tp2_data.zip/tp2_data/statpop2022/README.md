Ce dossier contient des données de la statistique de la population et des ménages (STATPOP) de l'OFS.

Vous trouvez plus d'informations sur STATPOP à l'URL suivante:
https://www.bfs.admin.ch/bfs/fr/home/statistiques/population/enquetes/statpop.html

Les données d'origine ont une résolution d'un hectare. Ces données sont décrites à l'URL suivante:
https://www.bfs.admin.ch/bfs/fr/home/services/geostat/geodonnees-statistique-federale/batiments-logements-menages-personnes/population-menages-depuis-2010.html

Sur la base des données à l'hectare, les sommes pour les communes et quartiers ont été calculés.

Description des fichiers:

- **be-f-00.03-10-STATPOP-v122.pdf**: ce fichier contient une description du jeu de données d'origine

- **bbe-b-00.03-10-STATPOP-v122-tab.xlsx**: ce fichier contient la liste des variables avec leur description.

- **statpop2022_qupg.ods**: les données elles-mêmes par communes et quartiers.

- **statpop2022.gpkg**: un fichier GeoPackage avec quelques données à l'hectare (où un hectare est représenté par un point).
