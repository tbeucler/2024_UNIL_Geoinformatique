Ce dossier contient des données de la statistique structurelle des entreprises (STATENT) de l'OFS.

Vous trouvez plus d'informations sur STATENT à l'URL suivante:
https://www.bfs.admin.ch/bfs/fr/home/statistiques/industrie-services/enquetes/statent.html

Les données d'origine ont une résolution d'un hectare. Ces données sont décrites à l'URL suivante:
https://www.bfs.admin.ch/bfs/fr/home/services/geostat/geodonnees-statistique-federale/etablissements-emplois/statistique-structurel-entreprises-statent-depuis-2011.html

Sur la base des données à l'hectare, les sommes pour les communes et quartiers ont été calculés.

Description des fichiers:

- **be-f-00 03-22-STATENT_N08-dat-v32.pdf**: ce fichier contient une description du jeu de données d'origine

- **be-b-00.03-22-STATENT_N08-var-v32-tab.xlsx**: ce fichier contient la liste des variables avec leur description.

- **statent2021_qupg.ods**: les données elles-mêmes par communes et quartiers.

- **statent2021.gpkg**: un fichier GeoPackage avec quelques données à l'hectare (où un hectare est représenté par un point).
